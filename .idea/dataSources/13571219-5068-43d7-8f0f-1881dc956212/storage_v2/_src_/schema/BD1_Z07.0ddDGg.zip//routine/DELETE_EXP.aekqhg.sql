create PROCEDURE delete_exp
    (p_exp_id expense.exp_id%type)
    IS
    BEGIN
    DELETE FROM expense WHERE exp_id = p_exp_id;
END delete_exp;
/

