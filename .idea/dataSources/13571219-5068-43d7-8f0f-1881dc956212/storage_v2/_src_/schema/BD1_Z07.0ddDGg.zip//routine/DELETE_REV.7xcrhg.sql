create PROCEDURE delete_rev
    (p_rev_id revenue.rev_id%type)
    IS
    BEGIN
    DELETE FROM revenue WHERE rev_id = p_rev_id;
END delete_rev;
/

