create PROCEDURE insert_exp
    (p_value expense.value%type,
     p_amount expense.amount%type,
     p_unit expense.unit%type,
     p_year expense.year%type,
     p_month expense.month%type,
     p_day expense.day%type,
     p_name expense.name%type,
     p_cat_name IN VARCHAR)
    IS
     v_cat_name exp_cat.e_cat_name%TYPE;
     v_cat_id exp_cat.e_cat_id%TYPE;

    test_val NUMBER;
    BEGIN

    SELECT COUNT(*) INTO test_val FROM exp_cat WHERE e_cat_name = p_cat_name AND rownum = 1;
    IF test_val = 1 THEN
        SELECT e_cat_id INTO v_cat_id FROM exp_cat WHERE e_cat_name = p_cat_name;
    ELSE
        INSERT INTO exp_cat
        (e_cat_id, e_cat_name)
        VALUES
        (exp_cat_id_seq.NEXTVAL, p_cat_name);
        COMMIT;
        SELECT e_cat_id INTO v_cat_id FROM exp_cat WHERE e_cat_name = p_cat_name;
    END IF;

    INSERT INTO expense
    (exp_id, value, amount, unit, year, month, day, name, e_cat_id)
    VALUES
    (exp_id_seq.NEXTVAL, p_value, p_amount, p_unit, p_year, p_month, p_day, p_name, v_cat_id);
END insert_exp;
/

