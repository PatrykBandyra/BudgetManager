create PROCEDURE insert_rev
    (p_value revenue.value%type,
     p_amount revenue.amount%type,
     p_unit revenue.unit%type,
     p_year revenue.year%type,
     p_month revenue.month%type,
     p_day revenue.day%type,
     p_name revenue.name%type,
     p_cat_name IN VARCHAR)
    IS
     v_cat_name rev_cat.r_cat_name%TYPE;
     v_cat_id rev_cat.r_cat_id%TYPE;

    test_val NUMBER;
    BEGIN

    SELECT COUNT(*) INTO test_val FROM rev_cat WHERE r_cat_name = p_cat_name AND rownum = 1;
    IF test_val = 1 THEN
        SELECT r_cat_id INTO v_cat_id FROM rev_cat WHERE r_cat_name = p_cat_name;
    ELSE
        INSERT INTO rev_cat
        (r_cat_id, r_cat_name)
        VALUES
        (rev_cat_id_seq.NEXTVAL, p_cat_name);
        COMMIT;
        SELECT r_cat_id INTO v_cat_id FROM rev_cat WHERE r_cat_name = p_cat_name;
    END IF;

    INSERT INTO revenue
    (rev_id, value, amount, unit, year, month, day, name, r_cat_id)
    VALUES
    (rev_id_seq.NEXTVAL, p_value, p_amount, p_unit, p_year, p_month, p_day, p_name, v_cat_id);
END insert_rev;
/

