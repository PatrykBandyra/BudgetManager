create PROCEDURE update_exp
    (p_exp_id expense.exp_id%type,
     p_value expense.value%type,
     p_amount expense.amount%type,
     p_unit expense.unit%type,
     p_year expense.year%type,
     p_month expense.month%type,
     p_day expense.day%type,
     p_name expense.name%type,
     p_cat_name IN VARCHAR)
    IS
     v_cat_name exp_cat.e_cat_name%TYPE;
     v_cat_id exp_cat.e_cat_id%TYPE;
     test_cat VARCHAR(20);
     test_val NUMBER;
    BEGIN
    --Update all the values except category 
    UPDATE expense SET 
        value=p_value,
        amount=p_amount,
        unit=p_unit,
        year=p_year,
        month=p_month,
        day=p_day,
        name=p_name WHERE exp_id = p_exp_id;
    --check current category
    SELECT e_cat_name INTO test_cat FROM exp_cat ec, expense exp WHERE exp.exp_id = p_exp_id AND exp.e_cat_id = ec.e_cat_id;
    IF p_cat_name != test_cat THEN
        SELECT COUNT(*) INTO test_val FROM exp_cat WHERE e_cat_name = p_cat_name AND rownum = 1;
        IF test_val = 1 THEN
            SELECT e_cat_id INTO v_cat_id FROM exp_cat WHERE e_cat_name = p_cat_name;
        ELSE
            INSERT INTO exp_cat
            (e_cat_id, e_cat_name)
            VALUES
            (exp_cat_id_seq.NEXTVAL, p_cat_name);
            COMMIT;
            SELECT e_cat_id INTO v_cat_id FROM exp_cat WHERE e_cat_name = p_cat_name;
        END IF;
    END IF;
    END update_exp;
/

