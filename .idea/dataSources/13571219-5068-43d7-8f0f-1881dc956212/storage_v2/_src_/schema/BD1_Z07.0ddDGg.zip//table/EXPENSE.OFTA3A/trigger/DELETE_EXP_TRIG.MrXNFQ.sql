create trigger DELETE_EXP_TRIG
    before delete
    on EXPENSE
    for each row
BEGIN
        --modify balance value
        UPDATE summary SET balance = balance+:OLD.value WHERE (month >= :OLD.month AND year = :OLD.year) OR year > :OLD.year;
END;
/

