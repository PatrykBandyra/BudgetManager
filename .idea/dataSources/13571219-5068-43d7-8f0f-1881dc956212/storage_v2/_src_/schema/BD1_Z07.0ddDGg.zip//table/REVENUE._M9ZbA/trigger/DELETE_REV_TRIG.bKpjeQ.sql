create trigger DELETE_REV_TRIG
    before delete
    on REVENUE
    for each row
BEGIN
        --modify balance value
        UPDATE summary SET balance = balance-:OLD.value WHERE (month >= :OLD.month AND year = :OLD.year) OR year > :OLD.year;
END;
/

