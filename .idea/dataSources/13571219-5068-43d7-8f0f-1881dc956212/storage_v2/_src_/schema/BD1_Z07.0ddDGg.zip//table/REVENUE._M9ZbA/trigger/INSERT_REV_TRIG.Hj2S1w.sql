create trigger INSERT_REV_TRIG
    after insert
    on REVENUE
    for each row
DECLARE
        val      INTEGER;
        val_mon  INTEGER;
        val_year INTEGER;
        test_val INTEGER;
        test_val2 INTEGER;
        prev_sum INTEGER;
    BEGIN
        --Get values of new insert
        val := :NEW.value;
        val_mon := :NEW.month;
        val_year := :NEW.year;
        --Check if the summary entry for given month exist
        SELECT COUNT(*) INTO test_val FROM summary WHERE val_mon = month AND val_year = year AND rownum = 1;
        IF test_val = 0 THEN
            SELECT COUNT(*) INTO test_val2 FROM summary WHERE (month < val_mon AND year = val_year) OR (year < val_year);
                IF test_val2 != 0 THEN
                    SELECT balance INTO prev_sum FROM
                    (SELECT * FROM summary WHERE (month < val_mon AND year = val_year) OR (year < val_year) ORDER BY year DESC, month DESC)
                    WHERE ROWNUM = 1;
                ELSE
                    prev_sum := 0;
                END IF;
            INSERT INTO summary(year, month, balance)
            VALUES(val_year, val_mon, prev_sum);
        END IF;
        UPDATE summary SET balance = balance+val WHERE month >= val_mon OR year > val_year;
END;
/

