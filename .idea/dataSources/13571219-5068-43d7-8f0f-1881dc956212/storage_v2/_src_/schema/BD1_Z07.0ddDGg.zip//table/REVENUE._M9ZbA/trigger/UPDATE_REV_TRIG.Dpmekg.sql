create trigger UPDATE_REV_TRIG
    before update
    on REVENUE
    for each row
BEGIN
        --modify balance value
        UPDATE summary SET balance = balance-:OLD.value WHERE (month >= :OLD.month AND year = :OLD.year) OR year > :OLD.year;
        DBMS_OUTPUT.PUT_LINE(:OLD.value);
        UPDATE summary SET balance = balance+:NEW.value WHERE (month >= :NEW.month AND year = :OLD.year) OR year > :NEW.year;
        DBMS_OUTPUT.PUT_LINE(:NEW.value);
END;
/

