create PROCEDURE insert_employee
    (p_employee_id IN NUMBER, p_first_name IN VARCHAR2, p_last_name IN VARCHAR2,
    p_email IN VARCHAR2, p_phone_number IN VARCHAR2, p_hire_date IN DATE,
    p_job_id IN VARCHAR2, p_salary IN NUMBER, p_commission_pct IN NUMBER,
    p_manager_id IN NUMBER, p_department_id IN NUMBER) 
    IS ex_last_name_null EXCEPTION; ex_email_null EXCEPTION;
       ex_email_not_unique EXCEPTION; ex_invalid_manager_id EXCEPTION;
       ex_invalid_department_id EXCEPTION; ex_job_id_null EXCEPTION;
       ex_invalid_job_id EXCEPTION; ex_invalid_salary EXCEPTION; 
       ex_invalid_hire_date EXCEPTION; ex_hire_date_null EXCEPTION;
       emp_id_flag BOOLEAN := FALSE; dep_id_flag BOOLEAN := FALSE;
       job_id_flag BOOLEAN := FALSE;
       v_min_salary NUMBER; v_max_salary NUMBER;
       v_current_date DATE;
BEGIN
    -- last name cannot be null
    IF p_last_name IS NULL THEN RAISE ex_last_name_null; END IF;
    
    -- email cannot be null and must be unique
    IF p_email IS NULL THEN RAISE ex_email_null; END IF;
    FOR emp_email IN (SELECT email FROM employees)
        LOOP
            IF emp_email.email = p_email THEN RAISE ex_email_not_unique; END IF;
        END LOOP;
    
    -- manager id can be null or must be id of different employee
    IF p_manager_id IS NOT NULL THEN
        FOR emp_id IN (SELECT employee_id FROM employees)
            LOOP
                IF emp_id.employee_id = p_employee_id THEN emp_id_flag := TRUE; EXIT; END IF;
            END LOOP;
         IF emp_id_flag = FALSE THEN RAISE ex_invalid_manager_id; END IF;
    END IF;
    
    -- department id can be null or must be in departments table
    IF p_department_id IS NOT NULL THEN
        FOR dep_id IN (SELECT department_id FROM departments)
            LOOP
                IF dep_id.department_id = p_department_id THEN dep_id_flag := TRUE; EXIT; END IF;
            END LOOP;
        IF dep_id_flag = FALSE THEN RAISE ex_invalid_department_id; END IF;
    END IF;
       
    -- job id cannot be null and must be in jobs table
    IF p_job_id IS NULL THEN RAISE ex_job_id_null; END IF;
    FOR j_id IN (SELECT job_id FROM jobs)
        LOOP
            IF j_id.job_id = p_job_id THEN job_id_flag := TRUE; EXIT; END IF;
        END LOOP;
    IF job_id_flag = FALSE THEN RAISE ex_invalid_job_id; END IF;
    
    -- salary must be proper for a given position
    SELECT min_salary INTO v_min_salary FROM jobs WHERE job_id = p_job_id;
    SELECT max_salary INTO v_max_salary FROM jobs WHERE job_id = p_job_id;
    IF p_salary NOT BETWEEN v_min_salary AND v_max_salary THEN RAISE ex_invalid_salary; END IF;
      
    -- hire date cannot be null and cannot be future date
    IF p_hire_date IS NULL THEN RAISE ex_hire_date_null; END IF;
    SELECT current_date INTO v_current_date FROM dual;
    IF p_hire_date > v_current_date THEN RAISE ex_invalid_hire_date; END IF;
    
    -- if no exception raised - insert values
    INSERT INTO employees VALUES(p_employee_id, p_first_name, p_last_name,
                                    p_email, p_phone_number,  p_hire_date, 
                                    p_job_id, p_salary, p_commission_pct, 
                                    p_manager_id, p_department_id);
EXCEPTION
    WHEN ex_last_name_null THEN RAISE_APPLICATION_ERROR(-20000, 'Last name cannot be null.');
    WHEN ex_email_null THEN RAISE_APPLICATION_ERROR(-20000, 'Email cannot be null.');
    WHEN ex_email_not_unique THEN RAISE_APPLICATION_ERROR(-20000, 'Email is not unique.');
    WHEN ex_invalid_manager_id THEN RAISE_APPLICATION_ERROR(-20000, 'Invalid manager id. No such employee.');  
    WHEN ex_invalid_department_id THEN RAISE_APPLICATION_ERROR(-20000, 'Invalid department id. No such department.');
    WHEN ex_job_id_null THEN RAISE_APPLICATION_ERROR(-20000, 'Job id cannot be null.');   
    WHEN ex_invalid_job_id THEN RAISE_APPLICATION_ERROR(-20000, 'Invalid job id. No such job.'); 
    WHEN ex_invalid_salary THEN RAISE_APPLICATION_ERROR(-20000, 'Invalid salary. Salary not suitable for a given job.');  
    WHEN ex_hire_date_null THEN RAISE_APPLICATION_ERROR(-20000, 'Hire date cannot be null.');
    WHEN ex_invalid_hire_date THEN RAISE_APPLICATION_ERROR(-20000, 'Invalid hire date. Hire date is a future date.');
END insert_employee;
/

